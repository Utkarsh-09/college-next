import Image from "next/image";
import "./globals.css";
import { Header } from "@/components/component/Header";
import { Two } from "@/components/component/two";
import { Three } from "@/components/component/three";
import { Four } from "@/components/component/four";
import { Five } from "@/components/component/five";
import { Six } from "@/components/component/six";
import { Seven } from "@/components/component/seven";
import { Footer } from "@/components/component/footer";


export default function Home() {
  return (
    <>
    <Header />
    <Two />
    <Three />
    <Four />
    <Five />
    <Six />
    <Seven />
    <Footer />
    </>
  );
}
