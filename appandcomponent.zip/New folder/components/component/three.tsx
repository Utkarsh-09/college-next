/**
 * v0 by Vercel.
 * @see https://v0.dev/t/O9Hy1qQ8mCU
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import Link from "next/link"
import Image from 'next/image';
import "./globals.css";
import '@mantine/core/styles.css';

export function Three() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-200">
      <div className="container grid items-center justify-center gap-4 px-4 text-center md:px-6 lg:gap-10">
        <div className="space-y-3">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-blue-900">Programs & Courses</h2>
          <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
            We offer a wide range of programs to help you achieve your academic and career goals.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-4 lg:gap-6">
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              01
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              01
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 1"
              className="object-cover w-full h-64"
              height={250}
              src="ballb.png"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
              sizes="(max-width: 768px) 100vw, 50vw"
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">B.A.LL.B HONS.</h3>
              <p className="text-sm text-gray-500">
              AFFILIATED WITH LUCKNOW UNIVERSITY
              </p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              02
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              02
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 2"
              className="object-cover w-full h-64"
              height={250}
              src="llb.jpg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">LL.B</h3>
              <p className="text-sm text-gray-500">AFFILIATED WITH LUCKNOW UNIVERSITY</p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              03
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              03
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 3"
              className="object-cover w-full h-64"
              height={250}
              src="dpharma.jpg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">D.PHARMA</h3>
              <p className="text-sm text-gray-500">APPROVED BY PHARMACY COUNCIL OF INDIA</p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              04
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              04
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 4"
              className="object-cover w-full h-64"
              height={250}
              src="bba.jpeg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">B.B.A</h3>
              <p className="text-sm text-gray-500">AFFILIATED WITH LUCKNOW UNIVERSITY</p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              05
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              05
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 5"
              className="object-cover w-full h-64"
              height={250}
              src="bcom.jpg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">B.COM</h3>
              <p className="text-sm text-gray-500">
              AFFILIATED WITH LUCKNOW UNIVERSITY
              </p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              06
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              06
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 6"
              className="object-cover w-full h-64"
              height={250}
              src="ba.jpg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">B.A.</h3>
              <p className="text-sm text-gray-500">AFFILIATED WITH LUCKNOW UNIVERSITY</p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              07
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              07
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 7"
              className="object-cover w-full h-64"
              height={250}
              src="del.webp"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">D.EL.ED (BTC)</h3>
              <p className="text-sm text-gray-500">
              APPROVED BY NATIONAL COUNCIL FOR TEACHER EDUCATION
              </p>
            </div>
          </div>
          <div className="relative group overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-transform duration-300 ease-in-out hover:-translate-y-2">
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              08
            </div>
            <div className="absolute inset-0 flex items-center justify-center p-4 text-2xl font-semibold text-gray-900 transform translate-x-full transition-all duration-300 group-hover:translate-x-0 dark:text-gray-50">
              08
            </div>
            <Link aria-label="View program" className="absolute inset-0 z-10" href="#" />
            <Image
              alt="Program 8"
              className="object-cover w-full h-64"
              height={250}
              src="iti.jpg"
              style={{
                aspectRatio: "500/250",
                objectFit: "cover",
              }}
              width={500}
            />
            <div className="bg-white p-4 grid gap-1 dark:bg-gray-950">
              <h3 className="font-bold text-lg">ITI</h3>
              <p className="text-sm text-gray-500">APPROVED BY NATIONAL COUNCIL FOR VOCATIONAL TRAINING (NCVT)</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

