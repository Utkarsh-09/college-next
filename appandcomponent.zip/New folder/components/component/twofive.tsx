/**
 * v0 by Vercel.
 * @see https://v0.dev/t/n11WfZsoN1M
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */

import { JSX, SVGProps } from "react"
import CountUp from 'react-countup';
import VisibilitySensor from 'react-visibility-sensor';
import "./globals.css";
import '@mantine/core/styles.css';

export default function Twofive() {
    return (
      <div className="bg-[#f7f7f7]">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-base font-semibold text-[#00bfa5] tracking-wide uppercase">ST. MOTHER TERESA GROUP OF COLLEGES</h2>
            <p className="mt-2 text-2xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-3xl">
              A Legacy of Educational Excellence
            </p>
          </div>
          <div className="flex justify-between">
            <div className="flex flex-col items-center">
              <GraduationCapIcon className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-4xl font-semibold text-gray-900">86%</p>
              <p className="mt-2 text-base text-gray-500">Overall Placement in Past 5 Years</p>
            </div>
            <div className="flex flex-col items-center">
              <GlobeIcon className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-4xl font-semibold text-gray-900">500+</p>
              <p className="mt-2 text-base text-gray-500">Alumni Settled across the Globe</p>
            </div>
            <div className="flex flex-col items-center">
              <UserIcon className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-4xl font-semibold text-gray-900">20+</p>
              <p className="mt-2 text-base text-gray-500">Faculty Members from Global Institutions</p>
            </div>
            <div className="flex flex-col items-center">
              <BookOpenIcon className="h-12 w-12 text-gray-400 mb-2" />
              <p className="text-4xl font-semibold text-gray-900">5,000+</p>
              <p className="mt-2 text-base text-gray-500">Students Enrolled in Different Courses</p>
            </div>
          </div>
        </div>
      </div>
    )
  }
  
  function BookOpenIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
      </svg>
    )
  }
  
  
  function GlobeIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="12" cy="12" r="10" />
        <line x1="2" x2="22" y1="12" y2="12" />
        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
      </svg>
    )
  }
  
  
  function GraduationCapIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
        <path d="M6 12v5c3 3 9 3 12 0v-5" />
      </svg>
    )
  }
  
  
  function UserIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
    return (
      <svg
        {...props}
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
        <circle cx="12" cy="7" r="4" />
      </svg>
    )
  }
  