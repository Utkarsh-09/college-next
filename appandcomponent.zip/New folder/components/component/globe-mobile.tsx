"use client";
import React from "react";
import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import { useEffect, useRef } from 'react';
import CountUp from 'react-countup';
import VisibilitySensor from 'react-visibility-sensor';




export default function Globemobile()
{
    return(
        <>
        <div className="sm:hidden">
<div className="flex-1 max-w-4xl mx-auto my-12 ">
  <h2 className="text-3xl font-bold text-center mb-8">Our student community is internationally diverse.</h2>
  <div className="grid grid-cols-2 gap-x-12 gap-y-8 max-[600px]:grid-cols-2 max-[600px]:gap-x-4 max-[600px]:gap-y-4 ">
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={500} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">PLACEMENT</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={200} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">INTERNSHIPS</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={2000} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">ALUMNI SUCCESS STORIES</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={100} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">PLACED ABROAD</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={50} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">STARTUP FUNDED</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={20} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">RESEARCH PROGRAM</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={10} duration={2.5} />
        ) : (
          0
        )} K+
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">BRILLIANT STUDENTS</span>
    </div>
    <div className="flex flex-col items-center">
    <VisibilitySensor>
    {({ isVisible }: any) => (
      <span className="text-5xl font-bold max-[600px]:text-base">
        {isVisible ? (
          <CountUp start={0} end={15} duration={2.5} />
        ) : (
          0
        )} +
      </span>
    )}
  </VisibilitySensor>
      <div className="w-12 h-1 bg-red-600 my-2" />
      <span className="text-xl max-[600px]:text-base">YEARS OF LEGACY</span>
    </div>
    
  </div>
  
  
  
</div>
</div>
</>
    )
}