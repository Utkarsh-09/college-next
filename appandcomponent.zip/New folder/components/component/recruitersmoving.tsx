"use client";

import React, { useEffect, useState } from "react";
import { InfiniteMovingCards } from "./infinite-moving-cards";
import "./globals.css";
import '@mantine/core/styles.css';

const testimonials = ['Adani-Web-Small.png', 'Amazon-Web-Small.png','Byjus-Web-Small.png','Cognizant-Web-Small.png','Dell -Web-Small.png','Deloitte-Web-Small.png','Dr. Lal Path Lab-Small.png','Flipkart-Web-Small.png','Google-Web-Small.png','Microsoft-Web-Small.png'];


export function Recruitersmoving() {
  return (
    <div className="h-[10rem] max-[600px]:h-[25rem] rounded-md flex flex-col antialiased bg-gray-200 dark:bg-black dark:bg-grid-white/[0.05] items-center justify-center relative overflow-hidden">
      <InfiniteMovingCards
        items={testimonials}
        direction="right"
        speed="slow"
      />
    </div>
  );
}

