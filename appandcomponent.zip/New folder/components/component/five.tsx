/**
 * v0 by Vercel.
 * @see https://v0.dev/t/a1KGkL3A0p9
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import { Button } from "@/components/ui/button"
import "./globals.css";
import '@mantine/core/styles.css';

export function Five() {
  return (
    <div className="bg-[#fde047] dark:bg-[#44337a] p-8">
      <div className="max-w-6xl mx-auto bg-[#fef3c7] dark:bg-[#2d1e46] p-4">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-[#b91c1c] dark:text-[#dc2626]">
            FULFILLING
            <span className="text-[#dc2626]"> CAREER DREAMS </span>
            THROUGH
          </h1>
          <h2 className="text-6xl font-extrabold text-[#dc2626] my-4">SMT SCHOLARSHIP</h2>
          <p className="text-2xl font-semibold text-[#b91c1c]">UPTO 100% SCHOLARSHIP ON TEST</p>
          <p className="text-xl font-medium text-[#92400e] my-4">IN THE MEMORY OF OUR FOUNDER DR. MADAN LAL KHURANA</p>
          <Button className="bg-[#991b1b] dark:bg-[#e31c3d] text-white py-2 px-8 mt-4">APPLY NOW</Button>
        </div>
      </div>
      {/* <div className="absolute top-4 right-4">
        <Image
          alt="100% Scholarship Badge"
          className="w-24 h-24 rounded-full"
          height={100}
          src="/placeholder.svg"
          style={{
            aspectRatio: "100/100",
            objectFit: "cover",
          }}
          width={100}
        />
      </div> */}
    </div>
  )
}

