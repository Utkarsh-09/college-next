/**
 * v0 by Vercel.
 * @see https://v0.dev/t/RRzufm6GDJT
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */

import "./globals.css";
import '@mantine/core/styles.css';
export function Four() {
  return (
    <>
    <div className="w-full  text-3xl font-semibold bg-black px-4 py-7 flex items-center justify-center text-white bg-opacity-50">SMT Group of Colleges Awarded Excellence with Quality Education Award by Deputy Chief Minister of Uttar
Pradesh
</div>
    <div
      className="relative w-full h-screen bg-cover bg-center"
      style={{
        backgroundImage: "url('/award.jpeg')",
      }}
    >
      <div className="absolute bottom-0 w-full p-4 bg-black bg-opacity-75">
        <div className="flex justify-between text-white">
          <div>
            <p className="px-40 font-bold text-2xl">Yuvraj Khurana</p>
            <p className="px-40 text-md">Director</p>
            <p className="px-40 text-md">St. Mother Teresa Group of Colleges</p>
          </div>
          <div>
            <p className="px-60 font-bold text-2xl">Dr. Dinesh Sharma</p>
            <p className="px-60 text-md">Deputy Chief Minister</p>
            <p className="px-60 text-md">Uttar Pradesh</p>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}

