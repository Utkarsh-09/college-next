/**
 * v0 by Vercel.
 * @see https://v0.dev/t/1cXr3fuTszB
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { DropdownMenuTrigger, DropdownMenuContent, DropdownMenu } from "@/components/ui/dropdown-menu"
import { JSX, SVGProps } from "react"

export function Headermobile() {
  return (
    <>
    <div className="sm:hidden">
    <header className="flex items-center justify-between px-4 py-3 bg-[#1e3a8a] shadow-sm">
      <Link className="flex items-center" href="#">
        <img
          alt="College Logo"
          className="rounded-full max-w-[64px] max-h-[64px]"
          src="smt.jpeg"
          style={{ objectFit: "cover" }}
        />
       <span
  className="ml-2 text-md font-medium text-[#fde047]"
  style={{
    fontSize: '3.125rem !important',
    lineHeight: '7.125rem !important',
  }}
>
  College Name
</span>
      </Link>
      <nav className="hidden md:flex items-center space-x-6">
        <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
          About
        </Link>
        <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
          Academics
        </Link>
        <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
          Admissions
        </Link>
        <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
          Contact
        </Link>
      </nav>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button className="md:hidden" size="icon" variant="outline">
            <MenuIcon className="h-6 w-6 text-[#fde047]" />
            <span className="sr-only">Toggle navigation menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent side="top">
          <div className="grid gap-4 p-6 bg-[#1e3a8a]">
            <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
              About
            </Link>
            <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
              Academics
            </Link>
            <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
              Admissions
            </Link>
            <Link className="text-[#fde047] hover:text-[#f59e0b]" href="#">
              Contact
            </Link>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
    </div>
    </>
  )
}

function MenuIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="4" x2="20" y1="12" y2="12" />
      <line x1="4" x2="20" y1="6" y2="6" />
      <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
  )
}
