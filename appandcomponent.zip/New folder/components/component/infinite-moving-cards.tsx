"use client";
import { cn } from "@/lib/utils";
import React, { useEffect, useRef } from "react";
import "./InfiniteMovingCards.css";
import { StaticImageData } from "next/image";
import Image from 'next/image';
import { Fullscreen } from "lucide-react";
import "./globals.css";
import '@mantine/core/styles.css';

export const InfiniteMovingCards = ({
    items,
    direction = "left",
    speed = "fast",
    pauseOnHover = true,
    className,
  }: {
    items: string[];
    direction?: "left" | "right";
    speed?: "fast" | "normal" | "slow";
    pauseOnHover?: boolean;
    className?: string;
  }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollerRef = useRef<HTMLUListElement>(null);

  useEffect(() => {
    addAnimation();
  }, []);

  function addAnimation() {
    if (containerRef.current && scrollerRef.current) {
      const scrollerContent = Array.from(scrollerRef.current.children);
      scrollerContent.forEach((item) => {
        const duplicatedItem = item.cloneNode(true);
        if (scrollerRef.current) {
          scrollerRef.current.appendChild(duplicatedItem);
        }
      });
      getDirection();
      getSpeed();
    }
  }

  const getDirection = () => {
    if (containerRef.current) {
      if (direction === "left") {
        containerRef.current.style.setProperty("--animation-direction", "forwards");
      } else {
        containerRef.current.style.setProperty("--animation-direction", "reverse");
      }
    }
  };

  const getSpeed = () => {
    if (containerRef.current) {
      if (speed === "fast") {
        containerRef.current.style.setProperty("--animation-duration", "20s");
      } else if (speed === "normal") {
        containerRef.current.style.setProperty("--animation-duration", "40s");
      } else {
        containerRef.current.style.setProperty("--animation-duration", "80s");
      }
    }
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        "scroller relative z-20 max-w-8xl overflow-hidden [mask-image:linear-gradient(to_right,transparent,white_10%,white_90%,transparent)]",
        className
      )}
    >
      <ul
        ref={scrollerRef}
        className={cn(
          "scroller-animation flex min-w-full shrink-0 gap-4 py-1 w-max flex-nowrap",
          pauseOnHover && "hover:[animation-play-state:paused]"
        )}
      >
        {items.map((item, idx) => (
  <li
    className="w-[350px] max-w-full relative rounded-2xl border border-b-0 flex-shrink-0 border-slate-700 px-8 py-1 md:w-[250px]"
    style={{ background: "linear-gradient(180deg, var(--slate-800), var(--slate-900))" }}
    key={idx}
  >
<Image 
  src={item} 
  alt={`Image ${idx}`} 
  className="w-full h-auto rounded-lg" 
  width={200}
  height={250}
  layout="responsive"
            // For screen sizes smaller than 600 pixels, reduce the image size
            sizes="(max-width: 600px) 100vw, 600px"
/>
  </li>
))}
      </ul>
    </div>
  );
};