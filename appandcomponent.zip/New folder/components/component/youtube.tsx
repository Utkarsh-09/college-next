"use client";

import Image from "next/image";
import React from "react";
import { CardBody, CardContainer, CardItem } from "./3d-card";
import Link from "next/link";
import "./globals.css";
import '@mantine/core/styles.css';

export function Youtube() {
  return (
    <>
    <div className="flex flex-wrap justify-center gap-9 max-[600px]:gap-1 bg-red-600">
    <CardContainer className="inter-var">
      <CardBody className="bg-gray-50 relative group/card  dark:hover:shadow-2xl dark:hover:shadow-emerald-500/[0.1] dark:bg-black dark:border-white/[0.2] border-black/[0.1] w-auto sm:w-[30rem] h-auto rounded-xl p-6 border  ">
        <CardItem
          translateZ="50"
          className="text-xl font-bold text-black"
        >
          Culture at SMT
        </CardItem>
        <CardItem
          as="p"
          translateZ="60"
          className="text-sm max-w-sm mt-2 text-black"
        >
          Embracing diversity and creativity, SMT celebrates unity through vibrant traditions and inclusive community engagement.
        </CardItem>
        <CardItem translateZ="100" className="w-full mt-4">
          <Image
            src="yt1.png"
            height="1000"
            width="1000"
            className="h-60 w-full object-cover rounded-xl group-hover/card:shadow-xl"
            alt="thumbnail"
            layout="responsive"
            // For screen sizes smaller than 600 pixels, reduce the image size
            sizes="(max-width: 600px) 100vw, 600px"
          />
        </CardItem>
        <div className="flex justify-between items-center mt-20">
          <CardItem
            translateZ={20}
            as={Link}
            href="https://youtu.be/tQcx2UPqXI8?si=n9ErMH2hbV4yedTn"
            target="__blank"
            className="px-4 py-2 rounded-xl text-xl font-normal text-black"
          >
            Play →
          </CardItem>
          {/* <CardItem
            translateZ={20}
            as="button"
            className="px-4 py-2 rounded-xl bg-black dark:bg-white dark:text-black text-white text-xs font-bold"
          >
            Sign up
          </CardItem> */}
        </div>
      </CardBody>
    </CardContainer>
    <CardContainer className="inter-var">
      <CardBody className="bg-gray-50 relative group/card  dark:hover:shadow-2xl dark:hover:shadow-emerald-500/[0.1] dark:bg-black dark:border-white/[0.2] border-black/[0.1] w-auto sm:w-[30rem] h-auto rounded-xl p-6 border  ">
        <CardItem
          translateZ="50"
          className="text-xl font-bold text-black"
        >
          Life at SMT
        </CardItem>
        <CardItem
          as="p"
          translateZ="60"
          className="text-black text-sm max-w-sm mt-2"
        >
           A dynamic journey enriched with academic excellence, holistic growth opportunities, and lifelong friendships, shaping individuals into confident and compassionate leaders of tomorrow.
        </CardItem>
        <CardItem translateZ="100" className="w-full mt-4">
          <Image
            src="yt2.png"
            height="1000"
            width="1000"
            className="h-60 w-full object-cover rounded-xl group-hover/card:shadow-xl"
            alt="thumbnail"
            layout="responsive"
            // For screen sizes smaller than 600 pixels, reduce the image size
            sizes="(max-width: 600px) 100vw, 600px"
          />
        </CardItem>
        <div className="flex justify-between items-center mt-20">
          <CardItem
            translateZ={20}
            as={Link}
            href="https://youtube.com/shorts/sCj0sysdUBo?si=nRXLNLH_0BXvhLfs"
            target="__blank"
            className="px-4 py-2 rounded-xl text-xl font-normal text-black"
          >
            Play →
          </CardItem>
          {/* <CardItem
            translateZ={20}
            as="button"
            className="px-4 py-2 rounded-xl bg-black dark:bg-white dark:text-black text-white text-xs font-bold"
          >
            Sign up
          </CardItem> */}
        </div>
      </CardBody>
    </CardContainer>
    <CardContainer className="inter-var">
      <CardBody className="bg-gray-50 relative group/card  dark:hover:shadow-2xl dark:hover:shadow-emerald-500/[0.1] dark:bg-black dark:border-white/[0.2] border-black/[0.1] w-auto sm:w-[30rem] h-auto rounded-xl p-6 border  ">
        <CardItem
          translateZ="50"
          className="text-xl font-bold text-black"
        >
          Fest at SMT
        </CardItem>
        <CardItem
          as="p"
          translateZ="60"
          className="text-black text-sm max-w-sm mt-2"
        >
           Ignites the spirit of celebration with exhilarating performances, interactive activities, and unforgettable memories, fostering a sense of camaraderie among students.
        </CardItem>
        <CardItem translateZ="100" className="w-full mt-4">
          <Image
            src="yt3.png"
            height="1000"
            width="1000"
            className="h-60 w-full object-cover rounded-xl group-hover/card:shadow-xl"
            alt="thumbnail"
            layout="responsive"
            // For screen sizes smaller than 600 pixels, reduce the image size
            sizes="(max-width: 600px) 100vw, 600px"
          />
        </CardItem>
        <div className="flex justify-between items-center mt-20">
          <CardItem
            translateZ={20}
            as={Link}
            href="https://youtu.be/sF50wV12bYw?si=lOy3VWKvBuO5Oz49"
            target="__blank"
            className="px-4 py-2 rounded-xl text-xl font-normal text-black"
          >
            Play →
          </CardItem>
          {/* <CardItem
            translateZ={20}
            as="button"
            className="px-4 py-2 rounded-xl bg-black dark:bg-white dark:text-black text-white text-xs font-bold"
          >
            Sign up
          </CardItem> */}
        </div>
      </CardBody>
    </CardContainer>
    </div>
    </>
  );
}
