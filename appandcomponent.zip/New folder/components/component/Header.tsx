/**
 * v0 by Vercel.
 * @see https://v0.dev/t/0bgMC0u4xi4
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from 'next/image';
import { JSX, SVGProps } from "react"
import "./globals.css";
import '@mantine/core/styles.css';

export function Header() {
  return (
    <header className="bg-gray-800" >
      {/* Single parent div containing all three divs */}
      <div className="flex items-center justify-between p-4 max-[600px]:flex-row">
        {/* First div containing the image */}
        <div>
          <Image
            alt="Logo"
            className="max-[600px]:h-20 max-[600px]:w-80"
            height="250"
            src="smtlogo.jpg"
            // style={{
            //   aspectRatio: "200/60",
            //   objectFit: "cover",
            // }}
            width="330"
          />
        </div>
        {/* <div className="text-white">
      <b className="block text-2xl max-[600px]:text-sm">ST. MOTHER TERESA</b>
      <b className="block text-2xl max-[600px]:text-sm">GROUP OF COLLEGES</b>
    </div> */}

        {/* Second div and Third div stacked on top of each other */}
        <div className="flex flex-col items-end space-y-4 w-10/12">
          {/* Second div containing buttons */}
          <div className="flex items-center space-x-4 max-[600px]:flex-row max-[600px]:text-sm max-[600px]:space-x-1">
            <Button className="bg-yellow-400 text-black hidden sm:block">Admission Open 2024</Button>
            <Link href="https://smtcollege.co.in">
    
        <button className="inline-flex h-12 animate-shimmer items-center justify-center rounded-md border border-slate-800 bg-[linear-gradient(110deg,#ffff00,45%,#1e2631,55%,#ffff00)] bg-[length:200%_100%] px-6 font-medium text-black transition-colors focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 focus:ring-offset-slate-50 max-[600px]:text-xs">
          Apply Now
        </button>
      
    </Link>





    <Link href="https://drive.google.com/file/d/1xQqRceWHEhGvbya2Q6CiCkUTXvWagLy9/view?usp=share_link">
            <Button className="bg-yellow-300 text-black bg-yellow-300 text-black px-4 py-2 sm:px-3 sm:py-1.5 sm:text-sm ">Download Brochure</Button>
            </Link>
            <FacebookIcon className="text-yellow-200 max-[600px]:h-10 max-[600px]:w-10 hidden sm:block" />
            {/* <TwitterIcon className="text-yellow-200 max-[600px]:h-10 max-[600px]:w-10"/> */}
            <LinkedinIcon className="text-yellow-200 max-[600px]:h-10 max-[600px]:w-10 hidden sm:block" />
            <YoutubeIcon className="text-yellow-200 max-[600px]:h-10 max-[600px]:w-10 hidden sm:block" />
            <Button className="bg-yellow-600 text-black hidden md:block">ADMISSION HELPLINE 7800004049</Button>
          </div>
          {/* Third div containing navigation */}
          <div className="bg-gray-700 p-4 w-full ">
            <nav className="flex justify-between max-[600px]:flex-row">
            <div className="flex items-centre space-x-14 max-[600px]:space-x-5 max-[600px]:space-y-4 max-[600px]:flex-row max-[600px]:text-xs">
                <Link className="text-white mx-2" href="#">
                  ABOUT US
                </Link>
                <Link className="text-white mx-2 hidden sm:block" href="#">
                  ACADEMICS
                </Link>
                <Link className="text-white mx-2" href="#">
                  COURSES
                </Link>
                <Link className="text-white mx-2 hidden sm:block" href="#">
                  ADMISSIONS
                </Link>
                <Link className="text-white mx-2 hidden sm:block" href="#">
                  CAMPUS LIFE
                </Link>
                <Link className="text-white" href="#">
                  PLACEMENTS
                </Link>
                {/* <Link className="text-white" href="#">
                  RESEARCH AND INNOVATION
                </Link> */}
              </div>
              {/* <div className="flex items-center space-x-4">
                <SearchIcon className="text-yellow-200" />
                <MenuIcon className="text-yellow-200" />
              </div> */}
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
}


       


function FacebookIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24 "
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  )
}




function LinkedinIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
      <rect width="4" height="12" x="2" y="9" />
      <circle cx="4" cy="4" r="2" />
    </svg>
  )
}


function MenuIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="4" x2="20" y1="12" y2="12" />
      <line x1="4" x2="20" y1="6" y2="6" />
      <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
  )
}




function SearchIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  )
}



function TwitterIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
    </svg>
  )
}


function YoutubeIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  )
}
