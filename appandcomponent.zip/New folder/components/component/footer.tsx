/**
 * v0 by Vercel.
 * @see https://v0.dev/t/cp9tEKCgO8d
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { JSX, SVGProps } from "react"
import Image from 'next/image';
import "./globals.css";
import '@mantine/core/styles.css';
export default function Footer() {
  return (
    <footer className="w-full pt-12 md:pt-24 pb-12 lg:pb-24 xl:pb-32 bg-gray-200">
      <div className="container grid gap-6 px-4 text-sm md:grid-cols-2 md:px-6 lg:grid-cols-4">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Image
              alt="College logo"
              className="aspect-square rounded-lg overflow-hidden object-cover"
              height="60"
              src="smt.jpeg"
              width="60"
            />
            <h1 className="text-xl font-semibold">SMT Group of Colleges</h1>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Providing quality education and opportunities for growth.
          </p>
        </div>
        <div className="grid gap-1">
          <h2 className="text-lg font-semibold">Programs & Courses</h2>
          <ul className="grid gap-1 max-[600px]:flex-col">
            <li className="max-[600px]:flex-col">
            <Link href="#" style={{ marginRight: '40px' }}>B.A.LL.B HONS.</Link>  
            </li>
            <Link href="#">LL.B</Link>
            <Link href="#">B.B.A</Link>
            <Link href="#">B.A.</Link>
            <Link href="#">ITI</Link>
            <li>
            <Link href="#" style={{ marginRight: '70px' }}>D.PHARMA</Link> 
            </li>
            <li>
            <Link href="#" style={{ marginRight: '97px' }}>B.COM</Link> 
            </li>
            <li>
            <Link href="#" style={{ marginRight: '50px' }}>D.EL.ED (BTC)</Link> 
            </li>
           
          </ul>
        </div>
        <div className="grid gap-1">
          <h2 className="text-lg font-semibold">Quick Links</h2>
          <ul className="grid gap-1">
            <li>
              <Link href="#">Admissions</Link>
            </li>
            <li>
              <Link href="#">Academics</Link>
            </li>
            <li>
              <Link href="#">Athletics</Link>
            </li>
            <li>
              <Link href="#">Library</Link>
            </li>
          </ul>
        </div>
        <div className="grid gap-1">
          <h2 className="text-lg font-semibold">Connect</h2>
          <ul className="grid gap-1">
            <li>
              <Link href="#">Campus Tour</Link>
            </li>
            <li>
              <Link href="#">Events</Link>
            </li>
            <li>
              <Link href="#">News</Link>
            </li>
            <li>
              <Link href="#">Alumni</Link>
            </li>
          </ul>
        </div>
        <div className="flex flex-col gap-1 md:col-span-2">
          <h2 className="text-lg font-semibold">Social Media</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Follow us for the latest updates and campus news.</p>
          <div className="flex gap-4">
            <Link
              className="rounded-full w-8 h-8 border border-gray-200 flex items-center justify-center hover:border-gray-900 dark:hover:border-gray-50"
              href="#"
            >
              <span className="sr-only">Follow us on Facebook</span>
              <FacebookIcon className="w-4 h-4 fill-current" />
            </Link>
            <Link
              className="rounded-full w-8 h-8 border border-gray-200 flex items-center justify-center hover:border-gray-900 dark:hover:border-gray-50"
              href="#"
            >
              <span className="sr-only">Follow us on Twitter</span>
              <TwitterIcon className="w-4 h-4 fill-current" />
            </Link>
            <Link
              className="rounded-full w-8 h-8 border border-gray-200 flex items-center justify-center hover:border-gray-900 dark:hover:border-gray-50"
              href="#"
            >
              <span className="sr-only">Follow us on Instagram</span>
              <InstagramIcon className="w-4 h-4 fill-current" />
            </Link>
            <Link
              className="rounded-full w-8 h-8 border border-gray-200 flex items-center justify-center hover:border-gray-900 dark:hover:border-gray-50"
              href="#"
            >
              <span className="sr-only">Follow us on LinkedIn</span>
              <LinkedinIcon className="w-4 h-4 fill-current" />
            </Link>
            <Link
              className="rounded-full w-8 h-8 border border-gray-200 flex items-center justify-center hover:border-gray-900 dark:hover:border-gray-50"
              href="#"
            >
              <span className="sr-only">Follow us on YouTube</span>
              <YoutubeIcon className="w-4 h-4 fill-current" />
            </Link>
          </div>
        </div>
        <div className="grid gap-1 md:col-span-2">
          <h2 className="text-lg font-semibold">Contact Us</h2>
          <p className="grid gap-1 text-sm text-gray-500 md:flex md:gap-2 dark:text-gray-400">
            <span>Call: +91 780 000 4049</span><br/>
            <span>Email: Admission@smtgc.edu.in</span><br/>
            <span>Office Hours: Mon-Fri 9am-5pm</span>
          </p>
        </div>
        <div className="grid gap-1 md:col-span-2">
          <h2 className="text-lg font-semibold">Address</h2>
          <p className="text-sm flex items-center gap-1 text-gray-500 md:gap-2 dark:text-gray-400">
            <MapPinIcon className="w-4 h-4 fill-current" />
            D-139/3 INDIRA NAGAR LUCKNOW 
          </p>
        </div>
        <div className="grid gap-1 md:col-span-2">
          <h2 className="text-lg font-semibold">Newsletter</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Subscribe to our newsletter for updates.</p>
          <div className="flex max-w-sm gap-2">
            <Input placeholder="Enter your email" type="email" />
            <Button size="sm">Subscribe</Button>
          </div>
        </div>
      </div>
    </footer>
  )
}

function FacebookIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  )
}


function InstagramIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  )
}


function LinkedinIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
      <rect width="4" height="12" x="2" y="9" />
      <circle cx="4" cy="4" r="2" />
    </svg>
  )
}


function MapPinIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}


function TwitterIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
    </svg>
  )
}


function YoutubeIcon(props: JSX.IntrinsicAttributes & SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  )
}