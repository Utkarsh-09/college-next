// components/ResponsiveLayout.tsx
import React, { ReactNode } from 'react';
import "./globals.css";
import '@mantine/core/styles.css';

interface ResponsiveLayoutProps {
  children: ReactNode;
}

const ResponsiveLayout = ({ children }: ResponsiveLayoutProps) => {
  return (
    <div className="text-base sm:text-sm md:text-xs lg:text-xs xl:text-xs 2xl:text-xs sm:scale-90 md:scale-80 lg:scale-75 xl:scale-70 2xl:scale-65">
      {children}
    </div>
  );
};

export default ResponsiveLayout;