"use client";
import { motion } from "framer-motion";
import React from "react";
import { ImagesSlider } from "./imagesslider";
import Image from 'next/image';
import "./globals.css";
import '@mantine/core/styles.css';

export function Two() {
  const images = [
    "Web Image Of College-Page-1.jpg",
    "Web Image Of College-Page-2.jpg",
    "Web Image Of College-Page-3.jpg",
    "Web Image Of College-Page-4.jpg",
    "Web Image Of College-Page-5.jpg",
    "Web Image Of College-Page-6.jpg",
    "Web Image Of College-Page-7.jpg",

  ];
  return (
    <ImagesSlider className="h-[70rem] lg:h-[40rem] xl:h-[50rem] 2xl:h-[70rem] max-[600px]:h-[25rem] max-[410px]:h-[25rem]" images={images}>
      
      <motion.div
        initial={{
          opacity: 1,
          y: -80,
        }}
        animate={{
          opacity: 1,
          y: 0,
        }}
        transition={{
          duration: 0.6,
        }}
        className="z-50 flex flex-col justify-center items-center"
      >
        {/* <motion.p className="font-bold text-xl md:text-5xl text-center bg-clip-text text-transparent bg-gradient-to-b from-neutral-50 to-neutral-400 py-4">
        ST. MOTHER TERESA
GROUP OF COLLEGES 
        </motion.p> */}
        {/* <button className="px-4 py-2 backdrop-blur-sm border bg-emerald-300/10 border-emerald-500/20 text-white mx-auto text-center rounded-full relative mt-4">
          <span>Apply now →</span>
          <div className="absolute inset-x-0  h-px -bottom-px bg-gradient-to-r w-3/4 mx-auto from-transparent via-emerald-500 to-transparent" />
        </button> */}
      </motion.div>
    </ImagesSlider>
  );
}
