import Image from "next/image";

import { Header } from "@/components/component/Header";
import { Two } from "@/components/component/two";
import { Three } from "@/components/component/three";
import { Five } from "@/components/component/five";
import { Six } from "@/components/component/six";

import Twofive from "@/components/component/twofive";

import { Collage } from "@/components/component/collage";
import { Recruitersmoving } from "@/components/component/recruitersmoving";
import { Youtube } from "@/components/component/youtube";
import { Globe } from "@/components/component/globe-component";
// import { Eight } from "@/components/component/eight";
import { createTheme, MantineProvider } from '@mantine/core';
import Footer from "@/components/component/footer";
import Globemobile from "@/components/component/globe-mobile";
import { Headermobile } from "@/components/component/HeaderMobile";
// import { Headermobile } from "@/components/component/HeaderMobile";





export default function Home() {
  return (
    <>
    <Headermobile />
    <Header />
    <Two />
    <Twofive/>
    <MantineProvider>
    <Three />
    </MantineProvider>
    <Globemobile />
    <Globe />
    {/* <Four /> */}
    <Five />
    <Six />
    
    
    
    <Collage />
    
    {/* <Eight /> */}
    
    <Recruitersmoving />
    <Youtube />
    <Footer />
    
    </>
  );
}
